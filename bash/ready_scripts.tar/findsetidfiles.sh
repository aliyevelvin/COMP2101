#!/bin/bash
#
# this script generates a report of the files on the system that have the setuid permission bit turned on
# it is for the lab1 exercise
# it uses the find command to find files of the right type and with the right permissions, and an error redirect to
# /dev/null so we do not get errors for inaccessible directories and files
# the identified files are sorted by their owner

# Task 1 for the exercise is to modify it to also display the 12 largest regular files in the system, sorted by their sizes
# The listing should
#    only have the file name, owner, and size of the 12 largest files
#    show the size in human friendly format
#    be displayed after the listing of setuid files
#   should have its own title, similar to how the setuid files listing has a title
# use the find command to generate the list of files with their sizes, with an error redirect to /dev/null
# use cut or awk to display only the output desired

echo "Setuid files:"
echo "============="
find / -type f -executable -perm -4000 -ls 2>/dev/null | sort -k 5
echo ""

echo "12 largest files:"
echo "============="
find / -type f  -printf "%kKB %p\n" 2>/dev/null | sort -nr | head -n 12 |  find . -type f  -printf "%kKB %p\n" | sort -nr | head -n 12 | cut -d " " -f2  | xargs -n1 ls -lhtr | awk '{print $9 " " $3 " " $5}' | awk '{n=split($0,a,"/"); print a[n]}'
echo ""
# for the task, add
# commands to display a title
# commands to make a list of the 12 biggest files
# sort/format whatever to display the list properly

