#!/bin/bash
# My first script - helloworld.sh

echo 'Hello World!'
echo "I am process # $$"
