#!/bin/bash
# My second script - helloworldtemplated.sh

cat <<EOF
Hello World!
I am process # $$
EOF
